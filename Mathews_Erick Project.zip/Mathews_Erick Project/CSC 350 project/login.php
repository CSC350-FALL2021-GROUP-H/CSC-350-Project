<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
</head>
<body>

<section class="signup_form">
    <h2>Please login to the laundry app</h2>
        <input type="text" name="user_name" placeholder="UserName">
        <input type="password" name="pw" placeholder="password">
        <input type="text" name="apt_num" placeholder="Enter your Apartment Number">
        <button type="submit" name="submit">Log In</button>

        <a href="signup.php">Don't have an account? click here to Signup</a>
        
<?php
require_once 'C:\xampp\htdocs\extra\dbc.php';
require_once 'C:\xampp\htdocs\extra\login-function.php';
?>
</section>

</body>
</html>
